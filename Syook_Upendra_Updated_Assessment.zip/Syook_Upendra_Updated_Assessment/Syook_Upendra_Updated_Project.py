# Name: Upendra V
# Date: 24-11-2023
# Problem Statement: To ingest accelerometer data from a real BLE Tag and detect whether the tag is moving or stationary.


import struct
import bluetooth

class BLEHandler:
	def __init__(self):
		# Bluetooth socket initialization
		self.server_sock = bluetooth.BluetoothSocket(bluetooth.L2CAP)
		self.port = 0x1001  # L2CAP PSM for Bluetooth LE
		self.server_sock.bind(("", self.port))
		self.server_sock.listen(1)
		print("Waiting for connection...")

		# Accept incoming Bluetooth connection
		self.client_sock, self.address = self.server_sock.accept()
		print(f"Accepted connection from {self.address}")

	def read_data(self):
		# Read data from the Bluetooth connection
		return self.client_sock.recv(1024)

def parse_accelerometer_packet(data):
	try:
		# Unpack accelerometer data from the packet
		data_length, frame_type, _, _, _, _, _, _, _, _, _, _, battery_level, x_axis, y_axis, z_axis, mac_address = struct.unpack('<BBBHHHhHhH6s', data)
		is_moving = x_axis != 0 or y_axis != 0 or z_axis != 0

		# Return parsed accelerometer data
		return 
		{
			'is_moving': is_moving,
			'battery_level': battery_level,
			'x_axis': x_axis / 256.0,
			'y_axis': y_axis / 256.0,
			'z_axis': z_axis / 256.0,
			'mac_address': ':'.join(f'{b:02X}' for b in reversed(mac_address))
		}
	except struct.error as e:
		# Handle struct errors during parsing
		print(f"Error parsing accelerometer packet: {e}")
		return None

def is_moving(accelerometer_data):
	# Check if the device is moving based on accelerometer data
	return accelerometer_data['is_moving']

def is_stationary(accelerometer_data):
	# Check if the device is stationary based on accelerometer data
	return not accelerometer_data['is_moving']

def check_battery_level(accelerometer_data):
	# Check battery level from accelerometer data
	return accelerometer_data['battery_level']

def main():
	# Initialize BLEHandler
	ble_handler = BLEHandler()

	# Provided raw packets
	raw_packets = [
		0x0201060303E1FF1216E1FFA10364FFF4000FFF003772A33F23AC,
		0x0201061AFF4C00021553594F4F4B534F4349414C444953544500000000E8,
		0x0201060303E1FF1216E1FFA10364FFF60011FF003772A33F23AC,
		0x0201061AFF4C00021553594F4F4B534F4349414C444953544500000000E8,
		0x0201060303E1FF1216E1FFA10364FFF40011FF033772A33F23AC,
		0x0201061AFF4C00021553594F4F4B534F4349414C444953544500000000E8,
	]

	try:
		for i, data in enumerate(raw_packets, start=1):
			accelerometer_data = parse_accelerometer_packet(data)

		if accelerometer_data:
			print(f"Packet {i} - Parsed Data:", accelerometer_data)
			print(f"Packet {i} - Device is moving:", is_moving(accelerometer_data))
			print(f"Packet {i} - Device is stationary:", is_stationary(accelerometer_data))
			print(f"Packet {i} - Battery Level:", check_battery_level(accelerometer_data))
			print("\n")

	except KeyboardInterrupt:
		pass
	finally:
		print("Closing connection...")
		# Close Bluetooth connection
		ble_handler.client_sock.close()
		ble_handler.server_sock.close()

if __name__ == "__main__":
	main()

