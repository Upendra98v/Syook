# Name: Upendra V
# Date: 18-11-2023
# Problem Statement: To ingest accelerometer data from a real BLE Tag and detect whether the tag is moving or stationary.

import struct
import bluetooth

class BLEHandler:
	def __init__(self):
		# Bluetooth socket initialization
		self.server_sock = bluetooth.BluetoothSocket(bluetooth.L2CAP)
		self.port = 0x1001  # L2CAP PSM for Bluetooth LE
		self.server_sock.bind(("", self.port))
		self.server_sock.listen(1)
		print("Waiting for connection...")

		# Accept incoming Bluetooth connection
		self.client_sock, self.address = self.server_sock.accept()
		print(f"Accepted connection from {self.address}")

	def read_data(self):
		# Read data from the Bluetooth connection
		return self.client_sock.recv(1024)

def parse_accelerometer_packet(data):
	try:
		# Unpack accelerometer data from the packet
		data_length, frame_type, _, _, _, _, _, _, _, _, _, _, battery_level, x_axis, y_axis, z_axis, mac_address = struct.unpack('<BBBHHHhHhH6s', data)
		is_moving = x_axis != 0 or y_axis != 0 or z_axis != 0

		# Return parsed accelerometer data
		return {
			'is_moving': is_moving,
			'battery_level': battery_level,
			'x_axis': x_axis / 256.0,
			'y_axis': y_axis / 256.0,
			'z_axis': z_axis / 256.0,
			'mac_address': ':'.join(f'{b:02X}' for b in reversed(mac_address))
		}
	except struct.error as e:
		# Handle struct errors during parsing
		print(f"Error parsing accelerometer packet: {e}")
		return None

def main():
	ble_handler = BLEHandler()

	try:
		while True:
			data = ble_handler.read_data()

		if not data:
			print("Connection closed.")
			break

		if len(data) >= 20 and data[4] == 0x03 and data[5:7] == b'\xE1\xFF':
			# Parse and print accelerometer data
			accelerometer_data = parse_accelerometer_packet(data)
			if accelerometer_data:
				print("Accelerometer Data:", accelerometer_data)

		elif len(data) >= 30 and data[4] == 0xFF and data[5:7] == b'\x4C\x00':
			# Handle iBeacon packet if needed
			print("iBeacon Data:", data)
		else:
			print("Unknown Packet Type")

	except KeyboardInterrupt:
		pass
	finally:
		print("Closing connection...")
		# Close Bluetooth connection
		ble_handler.client_sock.close()
		ble_handler.server_sock.close()

if __name__ == "__main__":
	main()

